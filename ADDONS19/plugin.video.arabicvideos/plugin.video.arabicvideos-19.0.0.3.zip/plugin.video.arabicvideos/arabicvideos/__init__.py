

import xbmcgui


xbmcgui.Dialog().ok('رسالة من المبرمج','برنامج عماد للفيديوهات العربية لا يعمل مع كودي 19 . قم بمسح كودي 19 بالكامل ثم اعد تثبيت كودي والبرنامج والجلد باستخدام هذا الرابط \nhttp://tiny.cc/kodiemad')


xbmcgui.Dialog().ok('Message from Emad','Emad "Arabic Videos" is not compatible with Kodi 19 . Delete all kodi 19 and install "KodiEmad" app from this  url (it contains kodi 18.9, skin, and arabic videos program):\n\nhttp://tiny.cc/kodiemad')



