from LIBRARY import *

MAIN()

#sys.exit(0)

#import TEST

#xbmcgui.Dialog().ok(str('__init__'),str(''))
