from LIBRARY import *

#xbmcgui.Dialog().ok('enter','__init__')

MAIN()

#xbmcgui.Dialog().ok('leave','__init__')

#sys.exit()

#import TEST

