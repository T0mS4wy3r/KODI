import xbmcgui,sys

mode = sys.argv[1]
keyboard = sys.argv[2]

xbmcgui.Dialog().ok('SKIN FOLDER',sys.argv[1]+' '+sys.argv[2])




